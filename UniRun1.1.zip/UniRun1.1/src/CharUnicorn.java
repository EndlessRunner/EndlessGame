
public class CharUnicorn extends Character{
	private int geschwidigkeit;
	private boolean tot;
	private int sprunghoehe;
}
