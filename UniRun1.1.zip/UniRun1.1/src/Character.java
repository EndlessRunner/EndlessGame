
public abstract class Character {
	
	public abstract void laufen();
	public abstract void sterben();
	public abstract boolean hitscan();
}
