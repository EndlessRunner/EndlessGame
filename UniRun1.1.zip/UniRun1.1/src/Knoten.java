
public class Knoten extends Listenelement{
	private Listenelement naechster;
	
	public Knoten(){
		
	}
	
	public double abstandBerechnen(int score){
		return Math.random()
	}
	public Listenelement hindernisSpawnen(double abstand)
		
	}	
}