import Java.Math.Random;
public abstract class Listenelement {
	public abstract Listenelement hindernisSpawnen(double abstand);
}
