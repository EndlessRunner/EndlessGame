
public class Datenelement {
 private Hindernis inhalt;
 public Datenelement(Hindernis i){
	 inhalt = i;
 }
}
