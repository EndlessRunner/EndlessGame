
public abstract class Hindernis {
	
}
