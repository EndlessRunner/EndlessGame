
public class Kaktus extends Hindernis{
	private int[][] hitbox;
}
