
public class Kaktus extends Hindernis{

}
