
public class CharUnicorn extends Character{

}
