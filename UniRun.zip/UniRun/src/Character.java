
public abstract class Character {

}
