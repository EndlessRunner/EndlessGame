
public class Datenelement {
 private Hindernis inhalt;
}
