
public abstract class Hindernis extends Datenelement {

}
